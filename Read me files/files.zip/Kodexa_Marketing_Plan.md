# Kodexa — Marketing Plan
### Catalog Manager Launch Campaign

---

## Overview

This document outlines the complete marketing plan for launching Catalog Manager by Kodexa across all social media platforms. The goal is to build a following, generate leads, and position Kodexa as the go-to AI software company for South African businesses.

---

## Platforms

| Platform | Handle | Status |
|---|---|---|
| LinkedIn | Kodexa | ✅ Active |
| Facebook | Kodexa | ✅ Active |
| YouTube | Kodexa | ✅ Active |
| Instagram | kodexa_sa | 🔄 In progress |
| TikTok | kodexa_sa | 🔄 To do |

---

## Video Assets

| Video | Status | Location |
|---|---|---|
| Catalog Manager promo (43 sec) | ✅ Created | C:\Projects\CatalogManager_Commercial\04_AI_Video |
| Kodexa brand video | 🔄 To create | — |
| Instagram Reel cut (30 sec) | 🔄 To create | — |
| TikTok cut (30 sec) | 🔄 To create | — |
| YouTube thumbnail | 🔄 To create | — |

---

## Tools Used

| Tool | Purpose | Cost | Status |
|---|---|---|---|
| HeyGen | AI avatar video | Free tier used up | ✅ Done |
| CapCut | Video editing | Free | 🔄 In progress |
| Canva | Graphics and thumbnails | Free | 🔄 In progress |
| Luma AI | Scene generation | Free tier available | 🔄 Next video |
| ElevenLabs | Voiceover | Free tier available | 🔄 Next video |

---

## Content Calendar

### WEEK 1 — Launch

| Day | Platform | Content |
|---|---|---|
| Day 1 | LinkedIn | Catalog Manager promo video + caption |
| Day 2 | Facebook | Same video + longer caption |
| Day 3 | YouTube | Full video uploaded with description and tags |
| Day 4 | LinkedIn | Behind the scenes — how we built it |
| Day 5 | Facebook | Problem/solution post — no video, just text |
| Day 6 | Instagram | Reel — 30 second cut of promo video |
| Day 7 | All platforms | Engagement — respond to all comments |

### WEEK 2 — Education

| Day | Platform | Content |
|---|---|---|
| Day 8 | LinkedIn | "5 reasons your product catalog is killing your sales" |
| Day 9 | YouTube | Tutorial — how to import Excel into Catalog Manager |
| Day 10 | Facebook | Customer pain point post |
| Day 11 | TikTok | 30 second demo of photo capture workflow |
| Day 12 | Instagram | Carousel — before and after product photos |
| Day 13 | LinkedIn | Kodexa brand video |
| Day 14 | All platforms | Engagement day |

### WEEK 3 — Social Proof

| Day | Platform | Content |
|---|---|---|
| Day 15 | LinkedIn | Case study — trailer parts company |
| Day 16 | YouTube | Full walkthrough video of Catalog Manager |
| Day 17 | Facebook | Share the case study |
| Day 18 | TikTok | "Watch me process 10 products in 10 minutes" |
| Day 19 | Instagram | Product photo before/after background removal |
| Day 20 | LinkedIn | "What does it cost to get 2000 products on Shopify?" |
| Day 21 | All platforms | Engagement day |

### WEEK 4 — Conversion

| Day | Platform | Content |
|---|---|---|
| Day 22 | LinkedIn | Limited offer post |
| Day 23 | YouTube | FAQ video — common questions about Catalog Manager |
| Day 24 | Facebook | Testimonial or results post |
| Day 25 | TikTok | Quick tip — AI product descriptions |
| Day 26 | Instagram | Reel — push to Shopify demo |
| Day 27 | LinkedIn | Direct outreach to target businesses |
| Day 28 | All platforms | Month 1 wrap up post |

---

## Caption Templates

### LinkedIn
```
[HOOK — one line problem statement]

[2-3 lines expanding the problem]

[Introduce the solution]

✅ [Feature 1]
✅ [Feature 2]
✅ [Feature 3]
✅ [Feature 4]

[Call to action]

👉 kodexa.co.za

#Kodexa #Shopify #Ecommerce #SouthAfrica #AI
```

### Facebook
```
[Longer story format — 4-6 lines]

[Features as bullet points]

[Strong call to action]

[Website link]

#Kodexa #SouthAfrica #SmallBusiness
```

### Instagram
```
[Short punchy hook — max 2 lines]
[2-3 emoji bullet points]
[CTA]
.
.
.
#Kodexa #Shopify #Ecommerce #SouthAfrica
#AI #SmallBusiness #ProductCatalog #OnlineStore
```

### TikTok
```
[Ultra short — 1 line hook]
[Quick value statement]
[Link in bio]
#Kodexa #AI #Shopify #SmallBusiness
```

---

## Target Audience

### Primary
- South African business owners with large product catalogs
- Wholesale and retail businesses moving online
- Manufacturers and distributors on Shopify
- Operations managers looking to reduce manual work

### Secondary
- Web developers and agencies (potential resellers)
- E-commerce consultants
- Shopify store owners struggling with catalog management

---

## Key Messages

1. **Pain:** Managing thousands of products manually wastes time and money
2. **Solution:** Catalog Manager automates the entire process
3. **Proof:** 2,036 products processed for a South African trailer manufacturer
4. **Differentiator:** Built in South Africa for South African businesses
5. **CTA:** Visit kodexa.co.za

---

## Hashtag Strategy

### Always use:
```
#Kodexa #SouthAfrica #AI #Shopify #Ecommerce
```

### Rotate these:
```
#SmallBusiness #OnlineStore #ProductCatalog
#DigitalBusiness #TechForAfrica #MadeInSA
#ShopifyStore #AItools #Automation
#BusinessSoftware #Entrepreneur #StartupSA
```

---

## Next Videos to Create

### Video 2 — Kodexa Brand Video (45 sec)
Tool: Luma AI + ElevenLabs + CapCut
Script: Already written (see Kodexa Brand Video Script)
Status: 🔄 To create

### Video 3 — Product Demo Walkthrough (2 min)
Tool: Screen recording + CapCut
Content: Full demo of Catalog Manager from start to finish
Status: 🔄 To create

### Video 4 — AI Description Demo (30 sec)
Tool: Screen recording + CapCut
Content: One click AI description generation — fast and satisfying
Status: 🔄 To create

### Video 5 — Before and After (30 sec)
Tool: CapCut
Content: Product photo with messy background → clean white background
Status: 🔄 To create

---

## Immediate To Do List

- [ ] Finish Instagram profile setup
- [ ] Create TikTok account
- [ ] Create YouTube thumbnail in Canva
- [ ] Fill in YouTube video title, description and tags
- [ ] Create 30 second Reel cut in CapCut
- [ ] Post Week 1 Day 4 content — behind the scenes
- [ ] Create Kodexa brand video (Video 2)
- [ ] Remove or cover HeyGen watermark on promo video
- [ ] Add background music to promo video in CapCut
- [ ] Set up Facebook ad account for future paid promotion

---

## Long Term Goals

| Timeframe | Goal |
|---|---|
| Month 1 | 500 followers across all platforms |
| Month 2 | First paying Catalog Manager client |
| Month 3 | 1,000 followers, 3 clients |
| Month 6 | Kodexa recognised brand in SA tech space |
| Month 12 | 5,000 followers, recurring software revenue |

---

## Support

**Daniel Boshoff — IT & Marketing**
Kodexa
info@kodexa.co.za
kodexa.co.za

---

*This marketing plan is a living document — update it as campaigns progress.*

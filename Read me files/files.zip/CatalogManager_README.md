# Catalog Manager
### by Kodexa | Version 1.0.0

---

## Overview

Catalog Manager is a Windows desktop application built to process large product catalogs and publish them directly to Shopify. It was built for businesses with hundreds or thousands of products that need to get online quickly, accurately, and without relying on expensive agencies or developers.

---

## Features

- Excel spreadsheet import (stock codes, names, categories, suppliers)
- Photo capture directly from iPhone or Android via browser
- Camera inbox — automatic detection of photos from professional cameras
- Automatic white background removal on every photo (rembg AI)
- AI-powered product description writing (Groq — LLaMA 3.3)
- Smart SKU generation based on category and stock code
- Direct Shopify API push — products, photos, prices, all in one click
- Progress dashboard with live stats and filters
- Multi-device access via local WiFi network
- Windows installer — no Python or dependencies required on target PC

---

## Tech Stack

- Python 3
- Flask (web framework)
- SQLite (database)
- Pillow (image processing)
- rembg (AI background removal)
- openpyxl (Excel import)
- requests (Shopify API)
- pyinstaller (Windows exe packaging)
- pystray (system tray)
- Groq API — LLaMA 3.3 70B (AI descriptions)
- Shopify Admin API 2024-01

---

## Folder Structure

```
catalog_manager/
├── app.py                  ← Flask application and all routes
├── database.py             ← SQLite database init and helpers
├── import_excel.py         ← Excel import script
├── shopify.py              ← Shopify API integration
├── image_utils.py          ← Background removal and image processing
├── launch.py               ← Entry point for Windows exe
├── make_icon.py            ← Generates app icon files
├── build.bat               ← PyInstaller build script
├── installer.iss           ← Inno Setup installer script
├── camera_inbox/           ← Drop photos here for auto-detection
├── static/
│   ├── style.css
│   ├── app.js
│   └── uploads/            ← Processed product photos stored here
├── templates/
│   ├── base.html
│   ├── index.html          ← Dashboard
│   ├── product.html        ← Product editing page
│   ├── settings.html       ← API keys and configuration
│   ├── setup.html          ← First run Excel import
│   └── help.html           ← User guide
└── exports/                ← CSV and JSON exports saved here
```

---

## Database Schema

```sql
products (
    id, stock_code, name, supplier, category,
    web_description, sell_price, compare_price,
    photos, tags, status, notes,
    shopify_handle, shopify_sku, shopify_id,
    shopify_pushed, shopify_pushed_at,
    created_at, updated_at
)

settings (
    key, value
)
```

---

## Setup — Development

```bash
pip install flask pillow openpyxl requests rembg pyinstaller pystray
python import_excel.py your_spreadsheet.xlsx
python app.py
```

Open browser: http://localhost:5001

---

## Setup — New PC (from installer)

1. Copy CatalogManager_Setup.exe to target PC
2. Double-click and install
3. Desktop shortcut created automatically
4. Double-click shortcut — browser opens automatically
5. Select Excel file on first run
6. Done — no Python required

---

## Building the Installer

```
1. pip install flask pillow openpyxl requests rembg pyinstaller pystray
2. Run build.bat
3. Test: dist/CatalogManager/CatalogManager.exe
4. Download Inno Setup: https://jrsoftware.org/isinfo.php
5. Open installer.iss in Inno Setup
6. Press F9 to compile
7. Find CatalogManager_Setup.exe in installer_output/
```

---

## Data Directory

When installed as exe all data is stored in:
```
C:\ProgramData\CatalogManager\
├── catalog.db
├── camera_inbox/
├── static/uploads/
└── exports/
```

This directory is never touched by updates so all data is preserved.

---

## Phone Access

1. Run ipconfig on laptop
2. Find IPv4 address e.g. 192.168.1.105
3. On phone browser: http://192.168.1.105:5001
4. Open any product and tap upload zone to use phone camera

---

## Camera Setup (Nikon D5600)

1. Install DigiCamControl from digicamcontrol.com
2. Open DigiCamControl before plugging in camera
3. Plug in Nikon D5600 via USB
4. Set Session folder to: C:\ProgramData\CatalogManager\camera_inbox\
5. Set Transfer to: Save to PC only
6. Every photo taken appears in app within 2 seconds

---

## API Keys Required

| Service | Purpose | Where to get |
|---|---|---|
| Groq | AI description writing | console.groq.com |
| Shopify | Push products to store | Shopify Admin → Settings → Apps → Develop apps |

Enter keys in app Settings page — no rebuild required.

---

## Shopify Integration

1. Go to Shopify Admin
2. Settings → Apps → Develop apps
3. Create app → Configure Admin API
4. Enable: write_products, read_products
5. Install → Reveal token
6. Enter token in Catalog Manager Settings
7. Click Test Connection — green = ready
8. Use Push to Shopify per product or Push all done products

---

## Updating the App

1. Make code changes on dev PC
2. Run build.bat
3. Compile installer.iss in Inno Setup
4. Distribute new CatalogManager_Setup.exe
5. Users install over old version
6. All data preserved in C:\ProgramData\CatalogManager\

---

## Known Limitations

- HeyGen free tier: 1 video per month
- rembg downloads 170MB model on first run (one time only)
- Shopify free plan does not include API access (Basic plan required)
- DigiCamControl does not support Nikon D5600 live view via USB (hardware limitation)

---

## Support

**Daniel Boshoff — IT**
Kodexa
info@kodexa.co.za
kodexa.co.za

---

*Catalog Manager is built and maintained by Kodexa. All rights reserved.*
